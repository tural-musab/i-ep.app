# [Numara]. [Kısa başlık]

## Bağlam

[Bu mimari kararın alınmasını gerektiren bağlamı açıklayın. Kararın gerekli olduğu durumu, kısıtlamaları ve gereksinimleri açıklayın.]

## Karar

[Alınan kararı net bir şekilde belirtin. Karar teknik olmalı ve neden bu kararın alındığını açıklamalıdır.]

## Durum

[Kararın durumunu belirtin: Önerilen, Kabul Edildi, Reddedildi, Değiştirildi, Eskidi]

## Tarih

[Kararın alındığı tarih, YYYY-AA-GG formatında]

## Sonuçlar

### Olumlu

- [Kararın olumlu etkileri]
- [...]

### Olumsuz

- [Kararın olumsuz etkileri veya yan etkileri]
- [...]

### Nötr

- [Kararın nötr etkileri veya değiş tokuşları]
- [...]

## Alternatifler

[Değerlendirilen alternatif çözümler ve bu alternatifler yerine bu kararın neden seçildiği]

## İlgili Kararlar

[İlgili mimari kararların referansları, varsa]

## Kaynaklar

[Karar için referans olarak kullanılan kaynaklar, belgeler, makaleler, vb.] 